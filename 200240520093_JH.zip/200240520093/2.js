function ReadValue() {
    let user = document.querySelector("#uid").value;
    let pass = document.querySelector("#pid").value;
    let email = document.querySelector("#eid").value;

    const readuser = document.querySelector("#userref");
    const readpass = document.querySelector("#passref");
    const reademail = document.querySelector("#emailref");

    readuser.innerHTML = user;
    readpass.innerHTML = pass;
    reademail.innerHTML = email;

    if (user == "") {
        alert("please enter username");
    }
    if (pass == "") {
        alert("please enter password");
    }
    if (email == "") {
        alert("please enter Email id");
    }


    document.querySelector("#uid").value = " ";
    document.querySelector("#pid").value = " ";
    document.querySelector("#eid").value = " ";
}